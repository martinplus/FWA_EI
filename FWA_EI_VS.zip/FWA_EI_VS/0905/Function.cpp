﻿#include "FireworkAlgorithm.h"
#include <math.h>
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

double ExternalCenter;
double LBOUND;
double UBOUND;
char CPU_FILE[15];
char FUNCTIONNAME[30];
int DIMENSION;


/*
 * benchmark.c
 *
 *  Created on: Aug 21, 2011
 *      Author: 

 */

/**
 * References:
 * 	[42] A. K. Qin, V. L. Huang, and P. N. Suganthan, “Differential evolu-
		tion algorithm with strategy adaptation for global numerical optimiza-
		tion,” IEEE Trans. Evol. Comput., vol. 13, no. 2, pp. 398–417, Apr.
		2009.
	[43] P. N. Suganthan, N. Hansen, J. J. Liang, K. Deb, Y.-P. Chen, A. Auger,
		and S. Tiwari, “Problem definitions and evaluation criteria for the
		CEC 2005 special session on real-parameter optimization,” Nanyang
		Technol. Univ. KanGAL, Singapore, IIT Kanpur, Kanpur, India, Tech.
		Rep. 2 005 005, 2005.
	[44] J. Liang, P. Suganthan, and K. Deb, “Novel composition test functions
		for numerical global optimization,” in Proc. IEEE Symp. Swarm Intell.,
		2005, pp. 68–75.
	[45] J. Vesterstrøm and R. Thomsen, “A comparative study of differential
		evolution particle swarm optimization and evolutionary algorithms on
		numerical benchmark problems,” in Proc. IEEE Congr. Evol. Comput.,
		vol. 3. Jun. 2004, pp. 1980–1987.
 */


void SetExternalCenter(int j)
{
	switch (j)
	{
	case 0:
		ExternalCenter = 0.0;
		break;
	case 1:
		ExternalCenter = 0.025 * (UBOUND - LBOUND);
		break;
	case 2:
		ExternalCenter = 0.05 * (UBOUND - LBOUND);
		break;
	case 3:
		ExternalCenter = 0.1 * (UBOUND - LBOUND);
		break;
	case 4:
		ExternalCenter = 0.15 * (UBOUND - LBOUND);
		break;
	case 5:
		ExternalCenter = 0.25 * (UBOUND - LBOUND);
		break;
	case 6:
		ExternalCenter = 0.35 * (UBOUND - LBOUND);
		break;
	default:
		ExternalCenter = 0.0;
		break;
	}
}


static int instance = -1;


// Shifted sphere function
double f1(double *x) {
	double f = 0;
	for(int i = 0;i < DIMENSION;i++)
	{  
		f += x[i]*x[i]; 
	}  
	return f;
}


//Schwefel's Problem 1.2
double f2(double *x) {
	double f = 0;
	double a;
	for(int i = 0; i < DIMENSION; i++)
	{
		a = 0.0;
		for(int j = 0; j <= i; j++)
			a += x[j];
		f += a * a;
	}
	return f;
}

// Rosenbrock’s function
double f3(double *x) {
	double f = 0;
	for(int i = 0; i < DIMENSION - 1; i++)
	{
		f += 100 * (x[i + 1] - x[i] * x[i]) * (x[i + 1] - x[i] * x[i]) + (x[i] - 1) * (x[i] - 1);
	}
	return f;
}

// Shifted Ackley’s function
double f4(double *x) {
	double f = 0;
	double a = 0.0;
	for(int i = 0; i < DIMENSION; i++)
	{                       
		f += x[i] * x[i];
		a += cos(2 * PI * x[i] * x[i]);
	}
	f = -0.2 * sqrt(f / DIMENSION);
	f = -20 * exp(f);
	a = -exp(a / DIMENSION);
	f += 20 + exp(1.0) + a;	
	return f;
}

//Generalized Griewank
double f5(double *x) {
	double f = 0;
	double a = 1.0;
	for(int i = 0; i < DIMENSION; i++)
	{                     
		f += x[i] * x[i];
		a *= cos(x[i] / sqrt(i + 1.0));
	}   
	f /= 4000;
	f += 1 - a;	

	return f;
}


// Penalized Function F8
double f6(double *x) {
	double f = 0;
	double miu = 0.0;
	double* y = (double*) calloc(DIMENSION, sizeof(double));
	
	for(int i = 0; i < DIMENSION; i++)
	{
		y[i] = 1 + 0.25 * (x[i] + 1);

		if(x[i] > 10)
			miu += 100 * (x[i] - 10) * (x[i] - 10) * (x[i] - 10) * (x[i] - 10);
		else if(x[i] < -10)
			miu += 100 * (x[i] + 10) * (x[i] + 10) * (x[i] + 10) * (x[i] + 10);
	}
	
	f += 10 * sin(PI * y[0]) * sin(PI * y[0]);

	for(int i = 0; i < DIMENSION - 1; i++)
		f += (y[i] - 1) * (y[i] - 1) * (1 + 10 * sin(PI * y[i + 1]) * sin(PI * y[i + 1]));

	f += (y[DIMENSION - 1] - 1) * (y[DIMENSION - 1] - 1);
	f *= PI / DIMENSION;
	f += miu;
	free(y);	

	return f;
}

// Penalized Function F16
double f7(double *x) {
	double f = 0;
	double miu = 0.0;

	for(int i = 0; i < DIMENSION; i++)
		if(x[i] > 5)
			miu += 100 * (x[i] - 5) * (x[i] - 5) * (x[i] - 5) * (x[i] - 5);
		else if(x[i] < -5)
			miu += 100 * (x[i] + 5) * (x[i] + 5) * (x[i] + 5) * (x[i] + 5);

	f += sin(3 * PI * x[0]) * sin(3 * PI * x[0]);

	for(int i = 0; i < DIMENSION - 1; i++)
		f += (x[i] - 1) * (x[i] - 1) * (1 + sin(3 * PI * x[i + 1]) * sin(3 * PI * x[i + 1]));

	f += (x[DIMENSION - 1] - 1) * (x[DIMENSION - 1] - 1) * (1 + sin(2 * PI * x[DIMENSION - 1]) * sin(2 * PI * x[DIMENSION - 1]));
	f *= 0.1;
	f += miu;
	
	return f;
}


//Six-hump Camel Back
double f8(double *x) {
	double f = 0;	
	f = 4 * x[0] * x[0] - 2.1 * x[0] * x[0] * x[0] * x[0] 
			+ x[0] * x[0] * x[0] * x[0] * x[0] * x[0] / 3.0
			+ x[0] * x[1] - 4 * x[1] * x[1] + 4 * x[1] * x[1] * x[1] * x[1];	

	return f;
}

// Goldstein-Price
double f9(double *x) {
	double f = 0;
	double a = 1 + (x[0] + x[1] + 1) * (x[0] + x[1] + 1) * (19 - 14 * x[0] + 3 * x[0] * x[0] - 14 * x[1] + 6 * x[0] * x[1] + 3 * x[1] * x[1]);
	double b = 30 + (2 * x[0] - 3 * x[1]) * (2 * x[0] - 3 * x[1]) * (18 - 32 * x[0] + 12 * x[0] * x[0] + 48 * x[1] - 36 * x[0] * x[1] + 27 * x[1] * x[1]);
	f = a * b;	

	return f;
}


//Schaffer
double f10(double *x) {
	double f = 0;
	
	double a = x[0] * x[0] + x[1] * x[1];
	f = 0.5 + (sin(sqrt(a)) * sin(sqrt(a)) - 0.5) / (1.0 + 0.001 * a);
	
	return f;
}

// Axis Parallel Hyper Ellipsoid
double f11(double *x) {
	double f = 0;
	
	for(int i = 0; i < DIMENSION; i++)
	{
		f += (i + 1) * x[i] * x[i];
	}
	
	return f;
}


//Rotated Hyper Ellipsoid
double f12(double *x) {
	double f = 0;
		
	double a;
	for(int i = 0; i < DIMENSION; i++)
	{
		a = 0.0;
		for(int j = 0; j <= i; j++)
			a += x[j];
		a *= a;
		f += a;
	}
	
	return f;
}

/**
 * Composition function 6: CF6 from [44]. 
 * The function f13 (CF6) is composed by using ten different benchmark functions, i.e., 
 * two rotated Rastrigin’s functions, two rotated Weierstrass functions, 
 * two rotated Griewank’s functions, two rotated Ackley’s functions, and two rotated Sphere functions.
 */
//Rastrigin
double f13(double *x) {
	double f = 0;
	
	for(int i = 0; i < DIMENSION; i++)
	{
		f += x[i] * x[i] - 10 * cos(2 * PI * x[i]);
	}
	f += 10 * DIMENSION;
	
	return f;
}

// 
double f14(double *x) {
	double f = 0;
	// TODO
	
	return f;
}

// 
double f15(double *x) {
	double f = 0;
	// TODO
	
	return f;
}

// 
double f16(double *x) {
	double f = 0;
	// TODO
	
	return f;
}

// 
double f17(double *x) {
	double f = 0;
	// TODO
	
	return f;
}

// 
double f18(double *x) {
	double f = 0;
	// TODO
	
	return f;
}

// 
double f19(double *x) {
	double f = 0;
	// TODO
	
	return f;
}

// 
double f20(double *x) {
	double f = 0;
	// TODO
	
	return f;
}

void benchmarkInitial(int instanceInstance){
	instance = instanceInstance;
	printf("%d\n", instance);

	switch (instance) {
		case 1:
			LBOUND = -100.0;
			UBOUND = 100.0;
			strcpy(CPU_FILE, "CPU_FILE1.txt");
			strcpy(FUNCTIONNAME, "Sphere");
			DIMENSION = 30;
			break;
		case 2:
			LBOUND = -100.0;
			UBOUND = 100.0;
			strcpy(CPU_FILE, "CPU_FILE2.txt");
			strcpy(FUNCTIONNAME, "Schwefel 1.2");
			DIMENSION = 30;
			break;
		case 3:
			LBOUND = -30.0;
			UBOUND = 30.0;
			strcpy(CPU_FILE, "CPU_FILE3.txt");
			strcpy(FUNCTIONNAME, "Generalized Rosenbrock");
			DIMENSION = 30;
			break;
		case 4:
			LBOUND = -32.0;
			UBOUND = 32.0;
			strcpy(CPU_FILE, "CPU_FILE4.txt");
			strcpy(FUNCTIONNAME, "Ackley");
			DIMENSION = 30;
			break;
		case 5:
			LBOUND = -600.0;
			UBOUND = 600.0;
			strcpy(CPU_FILE, "CPU_FILE5.txt");
			strcpy(FUNCTIONNAME, "Generalized Griewank");
			DIMENSION = 30;
			break;
		case 6:
			LBOUND = -50.0;
			UBOUND = 50.0;
			strcpy(CPU_FILE, "CPU_FILE6.txt");
			strcpy(FUNCTIONNAME, "Penalized Function F8");
			DIMENSION = 30;
			break;		
		case 7:
			LBOUND = -50.0;
			UBOUND = 50.0;
			strcpy(CPU_FILE, "CPU_FILE7.txt");
			strcpy(FUNCTIONNAME, "Penalized Function P16");
			DIMENSION = 30;
			break;
		case 8:
			LBOUND = -5.0;
			UBOUND = 5.0;
			strcpy(CPU_FILE, "CPU_FILE8.txt");
			strcpy(FUNCTIONNAME, "Six-hump Camel Back");
			DIMENSION = 2;
			break;		
		case 9:
			LBOUND = -2.0;
			UBOUND = 2.0;
			strcpy(CPU_FILE, "CPU_FILE9.txt");
			strcpy(FUNCTIONNAME, "Goldstein-Price");
			DIMENSION = 2;
			break;	
		case 10:
			LBOUND = -100.0;
			UBOUND = 100.0;
			strcpy(CPU_FILE, "CPU_FILE10.txt");
			strcpy(FUNCTIONNAME, "Schaffer");
			DIMENSION = 2;
			break;
		case 11:
			LBOUND = -5.12;
			UBOUND = 5.12;
			strcpy(CPU_FILE, "CPU_FILE11.txt");
			strcpy(FUNCTIONNAME, "Axis parallel hyper ellipsoid");
			DIMENSION = 30;
			break;
		case 12:
			LBOUND = -65.536;
			UBOUND = 65.536;
			strcpy(CPU_FILE, "CPU_FILE12.txt");
			strcpy(FUNCTIONNAME, "Rotated hyper ellipsoid");
			DIMENSION = 30;
			break;
		case 13:
			LBOUND = -5.12;
			UBOUND = 5.12;
			strcpy(CPU_FILE, "CPU_FILE13.txt");
			strcpy(FUNCTIONNAME, "Generalized rastrigin");
			DIMENSION = 30;
			break;
		default:
			printf("Benchmark instance %d not found in Initial.\n", instance);
			system("pause");
			exit(EXIT_FAILURE);
	}
}

double benchmarkEvaluation(double *x) {
	//evaluations++;

	switch (instance) {
		case 1:
			return f1(x);
		case 2:
			return f2(x);
		case 3:
			return f3(x);
		case 4:
			return f4(x);
		case 5:
			return f5(x);
		case 6:
			return f6(x);
		case 7:
			return f7(x);
		case 8:
			return f8(x);
		case 9:
			return f9(x);
		case 10:
			return f10(x);
		case 11:
			return f11(x);
		case 12:
			return f12(x);
		case 13:
			return f13(x);
		case 14:
			return f14(x);
		case 15:
			return f15(x);
		case 16:
			return f16(x);
		case 17:
			return f17(x);
		case 18:
			return f18(x);
		case 19:
			return f19(x);
		case 20:
			return f20(x);
		default:
			printf("Benchmark instance %d not found.\n", instance);
			system("pause");
			exit(EXIT_FAILURE);
	}
}
