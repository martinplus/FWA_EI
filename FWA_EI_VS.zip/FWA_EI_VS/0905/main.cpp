/*
 * main.cpp
 *
 *  Created on: April 11, 2016
 *      Author: Zhao Haitong
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "FireworkAlgorithm.h"
#include <string.h>

void running();
double FireworkAlgorithm(double*);
void SetExternalCenter(int);
void benchmarkInitial(int);


extern char CPU_FILE[15];
extern char FUNCTIONNAME[30];
extern int DIMENSION;

int main()
{
	running();
	system("Pause");
	return 0;
}

void running()
{
	
	//Random Seed	���������
	srand((unsigned int)time(NULL));

	//Ŀǰk��Χ����1-13
	for(int k = 1; k < 14; k++)
	{
		benchmarkInitial(k);
		printf("Now calculating function %s.\n", FUNCTIONNAME);

		//clock_t time_t
		clock_t start, end;
		//Prepare to write into file CPU_FILE д�ļ���CPU_FILE
		//FILE* fp = fopen(CPU_FILE, "w");		
		FILE* fp = fopen("1.txt", "a");	
		FILE* fp2 = fopen("2.txt", "a");
		FILE* fp3 = fopen("3.txt", "a");

		//Ŀǰj��Χ����0-6
		for(int j = 6; j < 7; j++)
		{
			//Best individual ���Ÿ���
			double* bestindividual = (double*) calloc(DIMENSION, sizeof(double));
			//Results for each time �洢ÿ�����е����Ž��
			double* results = (double*) calloc(RUNTIME, sizeof(double));
			//Used to calculate average and stardard deviation ���ڼ����ֵ�ͷ���
			double sum = 0.0;
			//Average �洢��ֵ
			double average = 0.0;
			//Quadratic summary ���ڼ����׼���ƽ����
			double quadratic = 0.0; 
			//Standard deviation �洢��׼��
			double deviation = 0.0;

			SetExternalCenter(j);
			//sum = 0.0;
			start = clock();

			for(int i = 0; i < RUNTIME; i++)
			{
				results[i] = FireworkAlgorithm(bestindividual) - F_BIAS;

				printf("#%d:\t%.9e\n", i, results[i]);
				fprintf(fp3, "%.9e\t", results[i]);
				sum += results[i];
			}
			fprintf(fp3, "\n");

			average = sum / RUNTIME;
			//quadratic = 0.0;
			for(int i = 0; i < RUNTIME; i++)
			{
				quadratic += (average - results[i]) * (average - results[i]);
			}
			deviation = sqrt(quadratic / RUNTIME);

			end = clock();

			printf("Error is %.9e +/- %.9e\n", average, deviation);
			fprintf(fp, "%.3e(%.1e)\t", average, deviation);

			//Calculates the difference in seconds between beginning and end.
			fprintf(fp2, "%.3f\t", difftime(end, start) / CLOCKS_PER_SEC);

			free(results);
			free(bestindividual);
		}
		
		fprintf(fp, "\n");
		fprintf(fp2, "\n");
		fprintf(fp3, "\n");

		fclose(fp);
		fclose(fp2);
		fclose(fp3);
	}
	
}
