/*
* main.cpp
*
*  Created on: April 11, 2016
*      Author: Zhao Haitong
*/

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <math.h>
#include <float.h>
#include "FireworkAlgorithm.h"

double benchmarkEvaluation(double*);
//Swap double value	��������double�͵���ֵ
void SwapDoubleValue(double*, double*);
//Round	�Ա��������뺯��
double round(double);
//Random function with bound	�����޵��������
double randBound(double, double);
//Normalization random function		Gaussian(1, 1)����
double randGaussian(double, double);
//Bound check function	�߽��麯��
void BoundCheck(double*, int);
//Bound check of random �߽���������
void BoundCheckinRandom(double*, int);

extern double ExternalCenter;
extern double LBOUND;
extern double UBOUND;
extern int DIMENSION;

double FireworkAlgorithm(double* bestindividual)
{
	double** population;
	double** newpopulation;
	double* fitness;
	double* newfitness;
	double bestfitness;
	int* flag;
	//double* distance;
	int SparkSize = N + MM + N * BM;
	int evaluateCount = 0;

	//double* tempindividual;
	//tempindividual = (double*)calloc(DIMENSION, sizeof(double));

	//Declaration	�������� ������double*
	population = (double**)calloc(N, sizeof(double*));
	for (int i = 0; i < N; i++)
		population[i] = (double*)calloc(DIMENSION, sizeof(double));

	newpopulation = (double**)calloc(SparkSize, sizeof(double*));
	for (int i = 0; i < SparkSize; i++)
		newpopulation[i] = (double*)calloc(DIMENSION, sizeof(double));

	fitness = (double*)calloc(N, sizeof(double));
	newfitness = (double*)calloc(SparkSize, sizeof(double));

	flag = (int*)calloc(DIMENSION, sizeof(int));
	//distance = (double*)calloc(SparkSize, sizeof(double));

	//Initialization	��ʼ���ռ�
	for (int i = 0; i < N; i++)
		for (int j = 0; j < DIMENSION; j++)
			population[i][j] = randBound(LBOUND, UBOUND);
			//population[i][j] = randBound(UBOUND / 2, UBOUND);
	//һ���ȼ����
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < DIMENSION; j++)
			population[i][j] -= ExternalCenter;

		fitness[i] = benchmarkEvaluation(population[i]);

		for (int j = 0; j < DIMENSION; j++)
			population[i][j] += ExternalCenter;
	}
	evaluateCount += N;

	//Begin iteration	��ʼ����
	for (int iter = 0; iter < GENERATION; iter++)
	{
		int i, j;
		//double maxIndex = -1, minIndex = -1;
		//int maxIndex = -1;
		int maxIndex = 0;
		//int minIndex = -1;
		double Ymax = fitness[0];
		double Ymin = fitness[0];
		//Calculate Ymax and Ymin
		for (j = 1; j < N; j++)
		{
			if (fitness[j] < Ymin)
			{
				Ymin = fitness[j];
				//minIndex = j;
			}

			if (fitness[j] > Ymax)
			{
				Ymax = fitness[j];
				maxIndex = j;
			}
		}

		//int individualNumber = N + MM;
		int pointer = 0;
		//memcpy	����ǰN��
		for (pointer = 0; pointer < N; pointer++)
			memcpy(newpopulation[pointer], population[pointer], sizeof(double) * DIMENSION);
		memcpy(newfitness, fitness, sizeof(double) * N);

		//Gaussian sparks	��˹����<<���б���ά��ȫ��һ��
		for (i = 0; i < MM; i++)
		{
			double randflag = 0;						//�������ʶ
			int selectGaussianID = rand() % N;
			for (j = 0; j < DIMENSION; j++)
			{
				//����0��10����������ٳ���10�õ�0��1�ľ�ȷ��ʮ��λС��
				randflag = (rand() % 10) / 10.0;
				if (randflag < 0.5)
				{
					int p = rand() % N;
					int q = rand() % N;
					int better = 0;
					better =
						benchmarkEvaluation(newpopulation[p]) < benchmarkEvaluation(newpopulation[q]) ?
					p : q;
					newpopulation[pointer][j] = newpopulation[selectGaussianID][j]
						+ (newpopulation[better][j] - newpopulation[selectGaussianID][j])
						*randGaussian(0, 1);
				}
			}

			//һ���ȼ����
			for (int j = 0; j < DIMENSION; j++)
				newpopulation[pointer][j] -= ExternalCenter;

			newfitness[pointer] = benchmarkEvaluation(newpopulation[pointer]);

			for (int j = 0; j < DIMENSION; j++)
				newpopulation[pointer][j] += ExternalCenter;

			pointer++;
			evaluateCount++;
		}

		double sum = 0.0;
		int* GeneratedSparks;
		GeneratedSparks = (int*)calloc(N, sizeof(int));
		//Calculate the number of sparks in formula 2	������ͨ�̻�����
		for (i = 0; i < N; i++)
			sum += Ymax - fitness[i];
		for (i = 0; i < N; i++)
		{
			//Consider the data loss
			GeneratedSparks[i] = M * (Ymax - fitness[i] + EPSILON) / (sum + EPSILON) + 0.5;
			//Boundary checking in formula 3
			if (GeneratedSparks[i] < AM) GeneratedSparks[i] = AM;
			if (GeneratedSparks[i] > BM) GeneratedSparks[i] = BM;
			//individualNumber += GeneratedSparks[i];
		}

		sum = 0.0;
		double* GeneratedAmplitude;
		
		GeneratedAmplitude = (double*)calloc(N, sizeof(double));
	
		//Calculate the amplitude of sparks in formula 4	������ȴ�С
		for (i = 0; i < N; i++)
			sum += fitness[i] - Ymin;
		for (i = 0; i < N; i++)
		{
			GeneratedAmplitude[i] = A * (fitness[i] - Ymin + EPSILON) / (sum + EPSILON);
			//Consider change
		}

		double Amin;
		double Ainit = (UBOUND - LBOUND) * 0.02;
		double Afinal = (UBOUND - LBOUND) * 0.001;;
		//Shaoqiu modify place A
		Amin = Ainit - (Ainit - Afinal) / FunctionEvaluations * sqrt((double)(2 * FunctionEvaluations - evaluateCount) * evaluateCount);

		for (i = 0; i < N; i++)
		{
			if (GeneratedAmplitude[i] < Amin)	GeneratedAmplitude[i] = Amin;
		}

		//Mu and Lambda are used to build linear migration model
		double* Mu;
		double* Lambda;
		Mu = (double*)calloc(N, sizeof(double));
		Lambda = (double*)calloc(N, sizeof(double));
		//Calculate value of mu_i and lambda_i
		double denominator = Ymax - Ymin + EPSILON;				//��ĸ
		for (i = 0; i < N; i++)
		{
			Mu[i] = (fitness[i] - Ymin + EPSILON) / denominator;
		}
		for (i = 0; i < N; i++)
		{
			Lambda[i] = (Ymax - fitness[i] + EPSILON) / denominator;
		}
		double muSum = 0;
		//muPoss is used to calculate the possibility whether firework will be chosed
		double* muPsb;
		muPsb = (double*)calloc(N, sizeof(double));
		for (i = 0; i < N; i++)
		{
			muSum += Mu[i];
		}
		for (i = 0; i < N; i++)
		{
			muPsb[i] = Mu[i] / muSum;
		}

		//Shaoqiu Modify place B and C
		int fireworksDirections;
		int fireworksSelectedIndex;
		double h;
		//Calculate fireworks algorithm
		for (i = 0; i < N; i++)
		{
			//randf is a random number between 0 and 1
			double randf = 0.0;
			randf = (rand() % 101) / 100.0;
			//randf����RHO, ���ó����̻���ը
			if (randf > RHO)
			{
				for (j = 0; j < GeneratedSparks[i]; j++)
				{
					//The number of affected directions z, at least explosion at 1 direction
					fireworksDirections = rand() % DIMENSION + 1;
					//Select z dimensions in flag array
					memset(flag, 0, sizeof(int) * DIMENSION);
					for (int k = 0; k < fireworksDirections; k++)
					{
						do
						{
							fireworksSelectedIndex = rand() % DIMENSION;
						} while (flag[fireworksSelectedIndex]);

						flag[fireworksSelectedIndex] = 1;
					}

					//in EFWA, h varies in each dimension
					for (int k = 0; k < DIMENSION; k++)
					{
						if (flag[k])
						{
							h = GeneratedAmplitude[i] * randBound(-1, 1);
							newpopulation[pointer][k] = population[i][k] + h;

							BoundCheckinRandom(newpopulation[pointer], k);
						}
						else
							newpopulation[pointer][k] = population[i][k];
					}
					//һ���ȼ����
					for (int k = 0; k < DIMENSION; k++)
					{
						newpopulation[pointer][k] -= ExternalCenter;
					}

					newfitness[pointer] = benchmarkEvaluation(newpopulation[pointer]);

					for (int k = 0; k < DIMENSION; k++)
					{
						newpopulation[pointer][k] += ExternalCenter;
					}

					pointer++;
					evaluateCount++;
				}
			}
			//randf������RHO, ����Ǩ�Ʋ���
			else
			{
				int selectedFW = 0;
				for (int d = 0; d < DIMENSION; d++)
				{
					//each of fireworks components has a probability of lambda_i of being changed
					randf = (rand() % 10) / 10.0;
					if (randf < Lambda[i]){
						//select another firework Xj with probability Mu
						int p = 0;				//counter
						double psb = 0.0;			//possibility sum
						randf = (rand() % 10) / 10.0;
						//the way to select another firework with probability in proportional to mu
						//selction used method here is like roulette way
						while (psb < 1 && p < N)
						{
							psb += muPsb[p];
							if (randf < psb)
							{
								selectedFW = p;
								break;
							}
							selectedFW = p;
							p++;
						}
						randf = (rand() % 10) / 10.0;
						if (randf < 0.5)
						{
							//set xi(d) according to eq.10
							newpopulation[i][d] = newpopulation[selectedFW][d];
						}
						else
						{
							//set xi(d) according to eq.11
							newpopulation[i][d] = newpopulation[i][d] +
								0.5*(newpopulation[selectedFW][d] - newpopulation[i][d]);
						}
					}
					//һ���ȼ����
					for (int k = 0; k < DIMENSION; k++)
					{
						newpopulation[i][k] -= ExternalCenter;
					}

					newfitness[i] = benchmarkEvaluation(newpopulation[i]);

					for (int k = 0; k < DIMENSION; k++)
					{
						newpopulation[i][k] += ExternalCenter;
					}
				}
				evaluateCount++;
			}
		}

		//Selection stratefy of FWA_EI, q at least as 1
		int q = rand() % (pointer - 1) + 1;
		//winsPool���ڴ洢i�����Ӧ��winsֵ������
		int** winsPool;
		winsPool = (int**)calloc(pointer, sizeof(int*));
		for (i = 0; i < pointer; i++)
		{
			winsPool[i] = (int*)calloc(2, sizeof(int));
		}
		//matrix to store q individuals
		int* selectPool;
		selectPool = (int*)calloc(q, sizeof(int));
		
		//initialize winsPool
		for (i = 0; i < pointer; i++)
		{
			winsPool[i][0] = i;
			winsPool[i][1] = 0;
		}
		for (i = 0; i < pointer; i++)
		{
			//randomly choose q opponents from the population
			for (j = 0; j < q; j++){
				int buf = rand() % pointer;
				if (buf != i){
					selectPool[j] = buf;
				}
				else
				{
					j = j - 1;
				}
			}
			//for each opponent
			for (j = 0; j < q; j++)
			{
				//����������
				if (newfitness[i] > newfitness[ selectPool[j] ])
				{
					winsPool[i][1] = winsPool[i][1] + 1;
				}
			}
		}
		//Sort pointer individuals in decreasing order of wins(xi)
		//select the first N individuals
		//����
		for (i = 0; i < pointer; i++)
		{
			int buf = 0;
			for (j = i + 1; j <pointer; j++)
			{
				if (winsPool[i][1] < winsPool[j][1])
				{
					buf = winsPool[i][0];
					winsPool[i][0] = winsPool[j][0];
					winsPool[j][0] = buf;
					buf = winsPool[i][1];
					winsPool[i][1] = winsPool[j][1];
					winsPool[j][1] = buf;
				}
			}
		}
		//Select top N individuals ordered by wins value in decreasing order into next generation
		for (int i = 0; i < N; i++){
			memcpy(population[i], newpopulation[ winsPool[i][0] ], sizeof(double) * DIMENSION);
			fitness[i] = newfitness[ winsPool[i][0] ];
		}

		for (int i = 0; i < pointer; i++)
			free(winsPool[i]);
		free(winsPool);
		free(selectPool);
		free(Mu);
		free(Lambda);
		free(GeneratedSparks);
		free(GeneratedAmplitude);

		//The End of Iteration
		if (evaluateCount >= FunctionEvaluations)
		{
			printf("\nCurrentIteration : %d", iter);
			break;
		}
	}


	printf("\nCurrentEvaluationCount : %d\n", evaluateCount);
	memcpy(bestindividual, population[0], sizeof(double) * DIMENSION);
	bestfitness = fitness[0];

	//free memory
	for (int i = 0; i < N; i++)
		free(population[i]);
	free(population);

	for (int i = 0; i < SparkSize; i++)
		free(newpopulation[i]);
	free(newpopulation);

	free(fitness);
	free(newfitness);
	free(flag);
	//free(distance);

	//free(tempindividual);
	return bestfitness;
}

void SwapDoubleValue(double* a, double* b)
{
	double temp;
	temp = *a;
	*a = *b;
	*b = temp;
}

//double randBound �޽��������
double randBound(double lower, double upper)
{
	return lower + (double)rand() / RAND_MAX * (upper - lower);
}

//Return a double number with Gaussian distribution	���Ӹ�˹�ֲ��������
//Under algorithm named box muller	ʹ��box muller�㷨
double randGaussian(double mu, double sigma)
{
	double x1 = 0.0;
	double x2, y;

	//Warning without outlet
	while (x1 == 0.0)
	{
		x1 = (double)rand() / RAND_MAX;
	}

	x2 = (double)rand() / RAND_MAX;

	//double log (double); ��eΪ�׵Ķ���
	y = sqrt(-2 * log(x1)) * cos(2 * PI * x2);
	double temp = mu + y * sigma;

	//_finite returns 0 if the argument is infinite or a NAN
	if (!_finite(temp))
	{
		printf("X1 means to zero in function randGaussian.\n");
		system("pause");
		exit(0);
	}
	return mu + y * sigma;
}

void BoundCheck(double* x, int y)
{
	if (x[y] < LBOUND || x[y] > UBOUND)
	{
		double absoluteValue = abs(x[y]);
		while (absoluteValue > 0)
			absoluteValue -= (UBOUND - LBOUND);
		x[y] = absoluteValue + UBOUND;
	}
}

void BoundCheckinRandom(double* x, int y)
{
	if (x[y] < LBOUND || x[y] > UBOUND)
		x[y] = randBound(LBOUND, UBOUND);
}
